﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEDOLValidation
{
    public class SEDOLs : ISedolValidationResult
    {
        public string InputString
        {
            get; set;
        }

        public bool IsUserDefined
        {
            get; set;
        }

        public bool IsValidSedol
        {
            get; set;
        }

        public string ValidationDetails
        {
            get; set;
        }
        public string sOuput
        {
            get; set;
        }
    }
}
