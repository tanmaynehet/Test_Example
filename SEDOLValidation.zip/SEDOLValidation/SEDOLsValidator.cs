﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SEDOLValidation
{
    public class SEDOLsValidator
    {
        SEDOLs obj = new SEDOLs();
        public ISedolValidationResult ValidateSedol(string input)
        {
            int iweightingfactor = 0;
            obj.InputString = input;
            if (validateSEDOL(input))
            {
                for (int i = 0; i <= input.Length - 1; i++)
                {
                    string sChar = input[i].ToString();
                    iweightingfactor += Getweightingfactor(i) * Getpattern(sChar);
                }
                obj.sOuput = Convert.ToString(10 - (iweightingfactor % 10) % 10);
            }
            else
            {
                obj.sOuput = "";
            }
            return obj;
        }
        bool validateSEDOL(string input)
        {
            if (Regex.IsMatch(input, @"[B-Db-dF-Hf-hJ-Nj-nP-Tp-tV-Xv-xYyZz0-9\d]{6}"))
            {
                obj.IsValidSedol = true;
                obj.IsUserDefined = true;
                obj.ValidationDetails = null;
                return true;
            }
            else
            {
                if (!input.Length.Equals(7)) obj.ValidationDetails = "Input string was not 7-characters long";
                else if (!Regex.IsMatch(input, @"^[a-zA-Z0-9 ]*$")) obj.ValidationDetails = "SEDOL contains invalid characters";
                else obj.ValidationDetails = "Invalid Checksum user defined SEDOL";
                obj.IsUserDefined = false;
                obj.IsValidSedol = false;
                return false;
            }
        }
        int Getweightingfactor(int iPosition)
        {
            int iFactoreValue = 0;
            switch (iPosition)
            {
                case 0:
                    iFactoreValue = 1;
                    break;
                case 1:
                    iFactoreValue = 3;
                    break;
                case 2:
                    iFactoreValue = 1;
                    break;
                case 3:
                    iFactoreValue = 7;
                    break;
                case 4:
                    iFactoreValue = 3;
                    break;
                case 5:
                    iFactoreValue = 9;
                    break;
                case 6:
                    iFactoreValue = 1;
                    break;
            }
            return iFactoreValue;
        }
        int Getpattern(string input)
        {
            int iVal = 0;
            int i = 0;
            if (!int.TryParse(input, out i))
            {
                char cVal = Convert.ToChar(input);
                iVal = char.ToUpper(cVal) - 64;
                iVal = iVal + 9;
            }
            else
            {
                iVal = Convert.ToInt32(input);
            }
            return iVal;
        }
    }
}
