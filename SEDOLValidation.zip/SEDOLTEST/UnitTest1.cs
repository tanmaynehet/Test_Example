﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEDOLValidation;
namespace SEDOLTEST
{
    [TestClass]
    public class UnitTest1
    { 
        [TestMethod]
        public void TestMethod1()
        {
            bool expected_result = true;
            //**Scenario:1**  Null, empty string or string other than 7 characters long
            string sValue = "123456711";
            var result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);
            sValue = "";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);

            //**Scenario:**  Invalid Checksum non user defined SEDOL
            sValue = "1234567";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);
         
            //**Scenario:**  Valid non user define SEDOL
            sValue = "0709954";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);
            sValue = "B0YBKJ7";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, true, result.ValidationDetails);

            //**Scenario** Invalid Checksum user defined SEDOL
            sValue = "9123451";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, true, result.ValidationDetails);
            sValue = "9ABCDE8";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, true, result.ValidationDetails);

            //**Scenario** Invaid characters found
            sValue = "9123_51";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);
            sValue = "VA.CDE8";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);

            //**Scenario:**Valid user defined SEDOL
            sValue = "9123458";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, false, result.ValidationDetails);

            sValue = "9ABCDE1";
            result = new SEDOLsValidator().ValidateSedol(sValue);
            Assert.AreEqual(result.IsValidSedol, true, result.ValidationDetails);
        }
    }
}
