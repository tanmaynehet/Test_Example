﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SEDOLValidation;
namespace SEDOLTEST
{
    [TestClass]
    public class UnitTest1
    { 
        [TestMethod]
        public void TestMethod1()
        {
            string sValue = "1234567";
            var result = new SEDOLsValidator().ValidateSedol(sValue);
        }
    }
}
